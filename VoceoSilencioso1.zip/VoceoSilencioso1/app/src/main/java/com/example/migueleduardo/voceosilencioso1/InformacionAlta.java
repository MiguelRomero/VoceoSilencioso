package com.example.migueleduardo.voceosilencioso1;

/**
 * Created by MiguelEduardo on 17/07/2017.
 */

public class InformacionAlta {

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getNombreauto() {
        return nombreauto;
    }

    public void setNombreauto(String nombreauto) {
        this.nombreauto = nombreauto;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

    public String getMarcaauto() {
        return marcaauto;
    }

    public void setMarcaauto(String marcaauto) {
        this.marcaauto = marcaauto;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String nombre;
    public String apellidos;
    public String matricula;
    public String nombreauto;
    public String celular;
    public String marcaauto;
    public String color;

    public InformacionAlta(){

    }

    public InformacionAlta(String nombre, String apellidos, String matricula, String nombreauto, String celular, String marcaauto, String color) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.matricula = matricula;
        this.nombreauto = nombreauto;
        this.celular = celular;
        this.marcaauto = marcaauto;
        this.color = color;
    }
}
